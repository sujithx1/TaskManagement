export interface UserStateTypes{
        id: string;
        _id?:string;
        name: string;
        email: string;
        phone: string;
        isBlocked?: boolean;
        authSourse?: string;
        role?: string;
        profilePic: string;
      
}

export interface UserInitialStatetypes{
    user:UserStateTypes|null,
    isAuthenticated:boolean

}