import SignUp from "./pages/signup/Signup"

const App = () => {
  return (
    <>

    <SignUp/>
    </>
  )
}

export default App